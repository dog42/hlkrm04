//DummyPKG M.Ulbricht
#include <stdio.h>
int main()
{printf("möp!\n");
return 0;
}
